//Arnav Kumar - 2016017
To run the code, extract files in a folder, open the command line and enter the command 'make'.
After that type ./server
In another terminal instance type ./client <ip address of machine running the server>.
You can open multiple instances of the terminal and have it each run a different client.
To find the ip address of your machine, type ifconfig and note down the IP of any interface.(My code will run on all interfaces).
